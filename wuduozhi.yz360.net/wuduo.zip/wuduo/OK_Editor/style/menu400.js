config.FixWidth = "";
config.UploadUrl = "uploadfile/";
config.InitMode = "EDIT";
config.AutoDetectPasteFromWord = "1";
config.BaseUrl = "1";
config.BaseHref = "";
config.AutoRemote = "1";
config.ShowBorder = "0";
config.StateFlag = "1";
config.SBCode = "1";
config.SBEdit = "1";
config.SBText = "1";
config.SBView = "1";
config.EnterMode = "1";
config.Skin = "office2003";
config.AllowBrowse = "1";
config.AllowImageSize = "100";
config.AllowFlashSize = "100";
config.AllowMediaSize = "100";
config.AllowFileSize = "500";
config.AllowRemoteSize = "100";
config.AllowLocalSize = "100";
config.AllowImageExt = "gif|jpg|jpeg|bmp";
config.AllowFlashExt = "swf";
config.AllowMediaExt = "rm|mp3|wav|mid|midi|ra|avi|mpg|mpeg|asf|asx|wma|mov";
config.AllowFileExt = "rar|zip|pdf|doc|xls|ppt|chm|hlp";
config.AllowRemoteExt = "gif|jpg|bmp";
config.AreaCssMode = "0";
config.SYWZFlag = "0";
config.SYTPFlag = "0";
config.ServerExt = "asp";

config.Toolbars = [
	["TBHandle", "FontNameMenu", "FontSizeMenu", "FormatBlockMenu", "TBSep", "EditMenu", "FontMenu", "ParagraphMenu", "ComponentMenu", "ObjectMenu", "ToolMenu", "FormMenu", "TableMenu", "FileMenu", "GalleryMenu", "TBSep", "ZoomMenu", "Maximize", "About"]
];
